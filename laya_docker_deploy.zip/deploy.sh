#!/usr/bin/env bash
# Laya Docker deployment for Docker 20.10, Linux x86_64, CUDA 12.8.
# GPU isolation: host GPU 5 -> laya-gpu5; host GPU 6 -> laya-gpu6.
# Intentionally retains all containers for post-mortem inspection.
set -Eeuo pipefail

BASE_DIR="${LAYA_BASE_DIR:-/opt/laya-docker}"
SRC_DIR="${BASE_DIR}/laya"
REPO_URL="https://github.com/NandhaKishorM/laya.git"
# Reviewed snapshot; override LAYA_GIT_REF to target a different revision.
GIT_REF="${LAYA_GIT_REF:-c73908d96ff73c0062c340a11bf7c54ec7d8bc4d}"
IMAGE="${LAYA_IMAGE:-laya:2.11.0-cu128}"
NETWORK="laya-net"
SECRET_DIR="${BASE_DIR}/secrets"
SECRET_FILE="${SECRET_DIR}/laya_api_key"
CONFIG_SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/nginx.conf"
NVIDIA_IMAGE="nvidia/cuda:12.8.0-base-ubuntu22.04"

usage() {
  cat <<'EOF'
Usage: bash deploy.sh COMMAND
  precheck  - inspect host, Docker and GPUs 5,6
  probe     - test NVIDIA GPU access inside Docker (saved probe container)
  clone     - clone and pin the reviewed Laya source revision
  build     - build image using torch 2.11.0 + cu128
  start     - create network/volumes/key, start GPU 5, GPU 6 and Nginx
  status    - display all 3 services and their host ports
  check     - test PyTorch CUDA access in the two service containers
  smoke     - run the example HTTP inference via the Nginx entrypoint
  logs      - show the most recent backend logs
  stop      - stop 3 containers, keeping them and the model volumes
  restart   - restart existing containers without recreation
  all       - precheck, probe, clone, build, start
Environment: LAYA_BASE_DIR, LAYA_GIT_REF, LAYA_IMAGE
EOF
}

precheck() {
  uname -m
  docker version --format 'Client {{.Client.Version}} / Server {{.Server.Version}}'
  nvidia-smi -i 5,6 --query-gpu=index,name,uuid,memory.total,memory.free,driver_version --format=csv
  if command -v nvidia-ctk >/dev/null 2>&1; then nvidia-ctk --version; fi
  docker info --format 'Runtimes: {{json .Runtimes}}'
}

probe() {
  if docker container inspect laya-gpu-probe >/dev/null 2>&1; then
    docker start -a laya-gpu-probe
  else
    docker run --name laya-gpu-probe --gpus '"device=5,6"' "$NVIDIA_IMAGE" nvidia-smi
  fi
}

clone_source() {
  mkdir -p "$BASE_DIR"
  if [ ! -d "${SRC_DIR}/.git" ]; then
    git clone "$REPO_URL" "$SRC_DIR"
    git -C "$SRC_DIR" checkout --detach "$GIT_REF"
  else
    printf 'Repository already exists: %s\n' "$SRC_DIR"
    printf 'Existing HEAD: '; git -C "$SRC_DIR" rev-parse HEAD
    printf 'Not overwriting your existing checkout.\n'
  fi
}

build_image() {
  [ -f "${SRC_DIR}/Dockerfile" ] || { echo 'Run clone first.' >&2; exit 2; }
  docker build \
    --build-arg TORCH_VERSION=2.11.0 \
    --build-arg TORCH_INDEX=cu128 \
    -t "$IMAGE" "$SRC_DIR"
}

prepare() {
  docker network inspect "$NETWORK" >/dev/null 2>&1 || docker network create "$NETWORK"
  docker volume inspect laya_cache_gpu5 >/dev/null 2>&1 || docker volume create laya_cache_gpu5
  docker volume inspect laya_cache_gpu6 >/dev/null 2>&1 || docker volume create laya_cache_gpu6
  mkdir -p "$SECRET_DIR"
  if [ ! -e "$SECRET_FILE" ]; then
    ( umask 077; openssl rand -hex 32 > "$SECRET_FILE" )
  fi
  # The repository's image runs with non-root UID 10001.
  chown 10001:10001 "$SECRET_FILE"
  chmod 0400 "$SECRET_FILE"
}

run_gpu() {
  local id="$1" port="$2" name="laya-gpu${1}" volume="laya_cache_gpu${1}"
  if docker container inspect "$name" >/dev/null 2>&1; then
    printf '%s exists; starting without changing its original configuration.\n' "$name"
    if [ "$(docker inspect --format '{{.State.Running}}' "$name")" = "true" ]; then
      printf '%s is already running.\n' "$name"
    else
      docker start "$name"
    fi
    return
  fi
  docker run -d \
    --name "$name" \
    --network "$NETWORK" \
    --gpus "\"device=${id}\"" \
    --restart unless-stopped \
    -p "127.0.0.1:${port}:8000" \
    -v "${volume}:/home/laya/.cache/huggingface" \
    -v "${SECRET_FILE}:/run/secrets/laya_api_key:ro,z" \
    -e LAYA_API_KEY_FILE=/run/secrets/laya_api_key \
    -e LAYA_DEVICE=cuda \
    -e LAYA_PORT=8000 \
    -e LAYA_HOST=0.0.0.0 \
    -e LAYA_PRELOAD=1 \
    -e LAYA_MODELS=english,multilingual \
    -e LAYA_MAX_LOADED=2 \
    -e LAYA_AUTO_TASK=0 \
    -e OMP_NUM_THREADS=4 \
    "$IMAGE" laya-serve
}

start_services() {
  docker image inspect "$IMAGE" >/dev/null 2>&1 || { echo 'Run build first.' >&2; exit 2; }
  [ -f "$CONFIG_SOURCE" ] || { echo "Missing $CONFIG_SOURCE" >&2; exit 2; }
  prepare
  run_gpu 5 8005
  run_gpu 6 8006
  if docker container inspect laya-lb >/dev/null 2>&1; then
    if [ "$(docker inspect --format '{{.State.Running}}' laya-lb)" != "true" ]; then docker start laya-lb; fi
  else
    docker run -d \
      --name laya-lb \
      --network "$NETWORK" \
      --restart unless-stopped \
      -p 127.0.0.1:8000:80 \
      -v "${CONFIG_SOURCE}:/etc/nginx/conf.d/default.conf:ro,Z" \
      nginx:stable-alpine
  fi
  status
}

status() {
  docker ps -a --filter 'name=laya-gpu' --filter 'name=laya-lb' \
    --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
}

check() {
  for name in laya-gpu5 laya-gpu6; do
    echo "### $name"
    docker inspect --format '{{json .HostConfig.DeviceRequests}}' "$name"
    docker exec "$name" python -c 'import torch; print("torch:",torch.__version__, "wheel_cuda:",torch.version.cuda); print("GPU count:",torch.cuda.device_count()); assert torch.cuda.is_available() and torch.cuda.device_count()==1; print("GPU:",torch.cuda.get_device_name(0)); print(torch.ones(1,device="cuda").cpu())'
  done
}

smoke() {
  [ -f "$SRC_DIR/examples/docker/request.json" ] || { echo 'Missing sample request; run clone.' >&2; exit 2; }
  local token
  token="$(cat "$SECRET_FILE")"
  curl -fsS http://127.0.0.1:8000/health
  printf '\n'
  curl -fsS -X POST http://127.0.0.1:8000/v1/systemone \
    -H 'Content-Type: application/json' \
    -H "Authorization: Bearer ${token}" \
    --data-binary "@${SRC_DIR}/examples/docker/request.json"
  printf '\n'
}

logs() {
  docker logs --tail 60 laya-gpu5
  docker logs --tail 60 laya-gpu6
}

stop_services() {
  for name in laya-lb laya-gpu5 laya-gpu6; do
    if docker container inspect "$name" >/dev/null 2>&1; then docker stop "$name"; fi
  done
}

restart_services() {
  for name in laya-gpu5 laya-gpu6 laya-lb; do
    docker container inspect "$name" >/dev/null 2>&1 || { echo "Missing $name, run start first." >&2; exit 2; }
    docker restart "$name"
  done
}

case "${1:-}" in
  precheck) precheck ;;
  probe) probe ;;
  clone) clone_source ;;
  build) build_image ;;
  start) start_services ;;
  status) status ;;
  check) check ;;
  smoke) smoke ;;
  logs) logs ;;
  stop) stop_services ;;
  restart) restart_services ;;
  all) precheck; probe; clone_source; build_image; start_services ;;
  *) usage; exit 2 ;;
esac
