# Laya Docker 双 GPU 部署包

这个部署包对应 **Docker 20.10.12 / Linux x86-64 / CUDA 12.8**，仅将宿主机的 GPU 5、GPU 6 分配给 Laya，分别运行一个容器。Nginx 提供统一入口。**不会自动删除运行完成或停止的容器**。

## 1. 前置条件

- 具有 Docker 管理权限、可使用 `git`、`openssl`、`curl`、`nvidia-smi`。
- Docker 已正确安装 NVIDIA Container Toolkit，且 `docker run --gpus` 可用。否则必须由主机管理员安排工具包安装和 Docker 守护进程重启，避免影响其他业务容器。
- 有访问 `github.com`、PyPI、`download.pytorch.org`、Hugging Face（或 ModelScope）的网络能力。
- 默认端口 `8000`、`8005`、`8006` 未被占用。默认全部只映射到宿主机 `127.0.0.1`；生产远程访问推荐 SSH 隧道或 HTTPS 反向代理。
- 预留足够磁盘空间存储两份模型缓存，以及 CUDA/PyTorch 镜像层。

## 2. 部署方法

以 root 或具备相应权限的用户在 Linux 主机执行：

```bash
# 先把此压缩包解压到 /opt/laya-launch，保证 deploy.sh 与 nginx.conf 同目录
cd /opt/laya-launch
chmod +x deploy.sh

bash deploy.sh precheck
bash deploy.sh probe
bash deploy.sh clone
bash deploy.sh build
bash deploy.sh start

bash deploy.sh status
bash deploy.sh check
bash deploy.sh logs
bash deploy.sh smoke
```

首次 `start` 时，服务会加载 `english,multilingual` 两个 checkpoint，必要时联网下载模型权重；下载未完成前接口暂不可用，使用 `bash deploy.sh logs` 检查进度。`smoke` 必须在模型就绪后运行。`typed-decisions` 可在后续单独请求时按需加载；如果要预加载它，应在 `deploy.sh` 中调整 `LAYA_MODELS`、`LAYA_MAX_LOADED` 并经充分显存测试后创建新容器。

直接运行全流程的命令：

```bash
bash deploy.sh all
```

此命令不等同于最终的 GPU/模型推理验收；仍需执行 `check` 和 `smoke`。

脚本把仓库固定在分析时的 Git 提交 `c73908d96ff73c0062c340a11bf7c54ec7d8bc4d`。可通过 `LAYA_GIT_REF=<commit>` 在初次克隆时指定其他提交。

## 3. API 访问

```bash
TOKEN="$(cat /opt/laya-docker/secrets/laya_api_key)"

curl -fsS http://127.0.0.1:8000/health
curl -fsS http://127.0.0.1:8000/v1/systemone \
  -H "Authorization: Bearer ${TOKEN}" \
  -H 'Content-Type: application/json' \
  --data-binary @/opt/laya-docker/laya/examples/docker/request.json
```

单独验证两张卡对应的服务：

```bash
curl -fsS http://127.0.0.1:8005/health
curl -fsS http://127.0.0.1:8006/health
```

两个 Laya 实例的 Docker 内部设备名称均为 `cuda:0`，分别对应宿主机的 5 和 6；这不是映射错误。宿主机 GPU 0-4 不在分配范围内。

## 4. 运维

```bash
bash deploy.sh status
bash deploy.sh logs
bash deploy.sh stop
bash deploy.sh restart
```

`stop` 保留容器和模型 volume。第二次执行 `start` 将复用旧容器，不会用新环境变量覆盖它们。重新部署镜像或改变模型配置时，请使用 **不同的新容器名** 进行滚动迁移并保留旧容器供回退，避免误删正在运行的其他业务。

## 5. 构建参数与 ModelScope 备用方案

默认 Dockerfile 构建参数：

```bash
TORCH_VERSION=2.11.0
TORCH_INDEX=cu128
```

若 Hugging Face 在部署地不可访问，可以在原仓库中构建 ModelScope 预下载版本：

```bash
cd /opt/laya-docker/laya
docker build \
  --build-arg TORCH_VERSION=2.11.0 \
  --build-arg TORCH_INDEX=cu128 \
  --build-arg MODELSCOPE_MODEL='english multilingual' \
  -t laya:2.11.0-cu128-ms .
```

注意：此时要使用新的 `LAYA_IMAGE=laya:2.11.0-cu128-ms` **创建新容器** 才会使用新镜像。模型缓存命名卷可能遮蔽镜像内预下载的权重，不要直接复用已包含其它 revision 的旧卷；离线启动增加 `HF_HUB_OFFLINE=1`。

## 6. 安全说明

部署脚本会生成 API 密钥文件，所有 Laya 服务均要求 `Authorization: Bearer <key>`。文件归属 UID 10001，权限 0400。Nginx 容器不加载或缓存密钥。

请勿直接在公网开放无 HTTPS 保护的端口；Docker 20.10.12 属于较老版本，若运行在共享网络环境，还应通过宿主机防火墙、云安全组等进行网络隔离。

注意：部署包已经做过脚本语法和压缩文件结构检查，但没有访问你的服务器做真实 GPU/模型推理验证；最终结果以真实 `torch.cuda` 与 API 返回为准。
