#!/usr/bin/env python3
"""End-to-end CLM Docker deployment smoke test. Python standard library only."""
import argparse
import base64
import datetime
import json
import os
import sys
import time
import urllib.error
import urllib.request


def http_json(method, url, payload=None, timeout=300):
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(url, data=body, method=method)
    if body is not None:
        req.add_header('Content-Type', 'application/json')
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            code, raw = response.status, response.read()
    except urllib.error.HTTPError as exc:
        code, raw = exc.code, exc.read()
    data = None
    try:
        data = json.loads(raw.decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        data = {'raw': raw[:800].decode('utf-8', 'replace')}
    if code < 200 or code >= 300:
        raise RuntimeError(f'HTTP {code}: {json.dumps(data, ensure_ascii=False)[:1200]}')
    return data, round((time.perf_counter()-start)*1000, 1)


def dim(item):
    e = item['embedding']
    if isinstance(e, str):
        raw = base64.b64decode(e)
        if len(raw) % 4:
            raise ValueError('Embedding base64 float32 bytes not divisible by 4')
        return len(raw)//4
    return len(e)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--encoder-url', default='http://127.0.0.1:8090')
    p.add_argument('--clm-url', default='http://127.0.0.1:8700')
    p.add_argument('--repeat', type=int, default=5)
    p.add_argument('--timeout', type=int, default=300)
    p.add_argument('--report', default='clm_docker_report.json')
    a = p.parse_args()
    eurl, curl = a.encoder_url.rstrip('/'), a.clm_url.rstrip('/')
    report = {'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'results': [], 'config':vars(a)}

    def check(name, fn):
        start = time.perf_counter()
        try:
            data = fn()
            report['results'].append({'test':name,'status':'PASS','elapsed_ms':round((time.perf_counter()-start)*1000,1),'details':data})
            print(f'[PASS] {name}: {data}')
            return True
        except Exception as exc:
            report['results'].append({'test':name,'status':'FAIL','elapsed_ms':round((time.perf_counter()-start)*1000,1),'error':str(exc)})
            print(f'[FAIL] {name}: {exc}')
            return False

    def models_test():
        j, ms = http_json('GET', eurl+'/v1/models', timeout=15)
        ids = [x.get('id') for x in j.get('data',[])]
        assert 'qwen3-8b' in ids, ids
        return {'models':ids, 'ms':ms}

    def health_test():
        j, ms = http_json('GET', curl+'/health', timeout=15)
        assert j.get('ok') is True and j.get('embedder') is True, j
        assert 'clm-latest' in j.get('models',[]), j
        return {'models':j['models'],'cache':j.get('cache',{}).get('device'),'ms':ms}

    def single_embed():
        j, ms = http_json('POST', eurl+'/v1/embeddings', {'model':'qwen3-8b','input':['Hello CLM'],'encoding_format':'base64','truncate_prompt_tokens':2048}, a.timeout)
        assert len(j['data'])==1 and dim(j['data'][0])==4096
        return {'dimension':dim(j['data'][0]),'ms':ms}

    def batch_embed():
        texts=['The customer was charged twice.','Which team handles billing?','Engineering resolves outages.','Marketing writes advertisements.','用户订单重复扣费，请处理退款。']
        j, ms = http_json('POST',eurl+'/v1/embeddings',{'model':'qwen3-8b','input':texts,'encoding_format':'base64','truncate_prompt_tokens':2048}, a.timeout)
        assert len(j['data'])==len(texts)
        assert set(x['index'] for x in j['data'])==set(range(len(texts)))
        assert all(dim(x)==4096 for x in j['data'])
        return {'count':len(j['data']), 'dimension':4096,'ms':ms}

    rank_payload={'context':'The customer was charged twice for one order.', 'question':'Which team should handle this issue?', 'answers':['The billing team handles refunds and duplicate charges.','The engineering team develops new software features.','The marketing team creates advertising campaigns.']}
    def rank():
        j, ms=http_json('POST',curl+'/v1/rank',rank_payload,a.timeout)
        rows=j.get('ranked',[])
        assert j.get('model')=='clm-latest'
        assert len(rows)==len(rank_payload['answers'])
        assert [x['rank'] for x in rows]==list(range(1,len(rows)+1))
        assert set(x['candidate'] for x in rows)==set(rank_payload['answers'])
        probs=[float(x['prob']) for x in rows]
        assert all(0<=x<=1 for x in probs) and abs(sum(probs)-1.0)<0.005
        assert all(probs[i]>=probs[i+1] for i in range(len(probs)-1))
        return {'top_candidate':rows[0]['candidate'],'probabilities':probs,'ms':ms}

    def systemone():
        payload={'model':'clm-latest','state':'Production server unavailable for two hours; customers cannot connect.', 'questions':{
            'urgent':{'type':'noul','instructions':'Is this urgent?'},
            'department':{'type':'choice','instructions':'Who should respond?','criteria':{'technical':'Engineering and infrastructure support','billing':'Refunds and invoices','marketing':'Promotions'}},
            'severity':{'type':'score','instructions':'How severe is this incident?','criteria':['Minor','Moderate','Severe','Critical']}}}
        j, ms=http_json('POST',curl+'/v1/systemone',payload,a.timeout)
        answers=j['answers']
        assert 0<=float(answers['urgent']['noul'])<=1
        assert answers['department']['choice'] in payload['questions']['department']['criteria']
        assert 0<=float(answers['severity']['score'])<=3
        assert 'usage' in j
        return {'urgency':answers['urgent']['noul'],'department':answers['department']['choice'],'severity':answers['severity']['score'],'ms':ms}

    def repeat_test():
        for i in range(max(a.repeat,1)):
            j,_=http_json('POST',curl+'/v1/rank',rank_payload,a.timeout)
            assert len(j.get('ranked',[]))==3, f'iteration {i+1}: {j}'
        health,_=http_json('GET',curl+'/health',timeout=15)
        assert health.get('ok') is True and health.get('embedder') is True
        pools=health.get('cache',{}).get('pools',{})
        pool=pools.get('512',{})
        hits=pool.get('hits',0)
        assert hits > 0, f'No projection cache hits after {a.repeat} repeated requests: {pool}'
        return {'repeats':max(a.repeat,1),'cache_hits':hits,'cache_used':pool.get('used')}

    for name, fn in [('01_encoder_models',models_test),('02_clm_health',health_test),('03_single_embedding',single_embed),('04_batch_embedding',batch_embed),('05_rank',rank),('06_systemone',systemone),('07_repeat_and_cache',repeat_test)]:
        check(name,fn)
    success=all(r['status']=='PASS' for r in report['results'])
    report['summary']={'result':'PASS' if success else 'FAIL','passed':sum(x['status']=='PASS' for x in report['results']),'total':len(report['results'])}
    with open(a.report,'w',encoding='utf-8') as out:
        json.dump(report,out,ensure_ascii=False,indent=2)
    print('\nResult:',report['summary'], '\nReport:',os.path.abspath(a.report))
    sys.exit(0 if success else 1)

if __name__=='__main__':
    main()
