#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/root/CLM}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL_DIR="${MODEL_DIR:-$PROJECT_DIR/models/Qwen3-8B}"
CKPT_DIR="${CKPT_DIR:-$PROJECT_DIR/checkpoints}"
GPU_SELECTION="${GPU_SELECTION:-device=3,4}"
ATTENTION_BACKEND="${ATTENTION_BACKEND:-TRITON_ATTN}"

usage() {
  echo 'Usage: bash deploy.sh {build|gpu-test|start-encoder|start-api|status|logs-encoder|logs-api|stop}'
  echo 'Environment: PROJECT_DIR=/root/CLM ATTENTION_BACKEND=TRITON_ATTN GPU_SELECTION=device=3,4'
}

check_cmd() { command -v "$1" >/dev/null || { echo "ERROR: missing $1" >&2; exit 1; }; }
check_name_available() {
  if docker container inspect "$1" >/dev/null 2>&1; then
    echo "ERROR: container '$1' already exists. Inspect it before removing: docker ps -a --filter name=$1" >&2
    exit 1
  fi
}

case "${1:-}" in
  build)
    check_cmd docker
    test -f "$PROJECT_DIR/pyproject.toml" || { echo "Missing $PROJECT_DIR/pyproject.toml" >&2; exit 1; }
    test -d "$PROJECT_DIR/src/clm" || { echo "Missing $PROJECT_DIR/src/clm" >&2; exit 1; }
    mkdir -p "$HERE/src"
    cp -a "$PROJECT_DIR/src/." "$HERE/src/"
    cp "$PROJECT_DIR/pyproject.toml" "$PROJECT_DIR/README.md" "$HERE/"
    docker build --file "$HERE/Dockerfile.encoder" --tag clm-encoder:cu128 "$HERE"
    docker build --file "$HERE/Dockerfile.api" --tag clm-api:cpu "$HERE"
    ;;
  gpu-test)
    check_cmd docker
    docker run --rm --gpus '"device=3,4"' nvidia/cuda:12.8.1-base-ubuntu22.04 nvidia-smi -L
    ;;
  start-encoder)
    check_cmd docker
    test -f "$MODEL_DIR/config.json" || { echo "Missing model at $MODEL_DIR" >&2; exit 1; }
    check_name_available clm-encoder
    if ! docker network inspect clm-net >/dev/null 2>&1; then docker network create clm-net; fi
    mkdir -p "$PROJECT_DIR/docker-cache/encoder"
    # NOTE: Do not set CUDA_VISIBLE_DEVICES=3,4 INSIDE the container.
    # NVIDIA --gpus exposes only the selected host cards; CUDA renumbers them as 0,1.
    # Docker CLI needs a quoted device filter; GPU_SELECTION should be 'device=3,4'.
    docker run -d --name clm-encoder --network clm-net \
      --gpus "\"$GPU_SELECTION\"" \
      --shm-size=4g --restart unless-stopped \
      --log-driver=json-file --log-opt max-size=50m --log-opt max-file=3 \
      --publish 127.0.0.1:8090:8090 \
      --env "VLLM_ATTENTION_BACKEND=$ATTENTION_BACKEND" \
      --env CUDA_DEVICE_ORDER=PCI_BUS_ID \
      --volume "$MODEL_DIR:/models/Qwen3-8B:ro" \
      --volume "$PROJECT_DIR/docker-cache/encoder:/root/.cache" \
      clm-encoder:cu128
    echo 'Encoder launched; verify FIRST: docker logs -f clm-encoder'
    echo 'Then curl -fsS http://127.0.0.1:8090/v1/models and run a real embedding test.'
    ;;
  start-api)
    check_cmd docker
    test -f "$CKPT_DIR/CLM_v0.1-8B.pt" || { echo "Missing checkpoint at $CKPT_DIR" >&2; exit 1; }
    check_name_available clm-api
    docker container inspect clm-encoder >/dev/null || { echo 'Encoder container missing' >&2; exit 1; }
    # Verify basic vLLM model list before starting; real embedding is checked by test_clm.py.
    docker exec clm-encoder curl -fsS http://127.0.0.1:8090/v1/models >/dev/null || {
      echo 'Encoder not ready. Check docker logs clm-encoder' >&2; exit 1;
    }
    docker run -d --name clm-api --network clm-net \
      --restart unless-stopped \
      --log-driver=json-file --log-opt max-size=20m --log-opt max-file=3 \
      --publish 127.0.0.1:8700:8700 \
      --volume "$CKPT_DIR:/checkpoints:ro" \
      clm-api:cpu
    echo 'API launched; verify: docker logs -f clm-api'
    ;;
  status)
    docker ps -a --filter name=clm-encoder --filter name=clm-api
    ;;
  logs-encoder) docker logs --tail 150 clm-encoder ;;
  logs-api) docker logs --tail 150 clm-api ;;
  stop)
    # Only two named CLM containers; never touches other Docker/GPU workloads.
    docker stop clm-api clm-encoder
    ;;
  *) usage; exit 2 ;;
esac
