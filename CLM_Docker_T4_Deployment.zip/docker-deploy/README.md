# CLM x86_64 / NVIDIA T4 GPU 3、4 / CUDA 12.8 Docker 部署包

> 适配宿主机 Docker 20.10.12；**没有在用户服务器上实际执行镜像构建或推理验收**。请按步骤在目标宿主机验证。此包通过 **docker run** 而非依赖未知版本的 Docker Compose 部署。

## 架构

- `clm-encoder`: vLLM 0.11.2 / PyTorch 2.8.0 cu128 / Qwen3-8B FP16 / 2 卡张量并行 / Docker 专用网络内监听 `0.0.0.0:8090`，宿主机仅发布 `127.0.0.1:8090`。
- `clm-api`: CPU-only PyTorch 2.8.0 / CLM projection head / Docker 专用网络访问 `http://clm-encoder:8090/v1/embeddings`，宿主机仅发布 `127.0.0.1:8700`。
- 宿主机 ModelScope 文件：`/root/CLM/models/Qwen3-8B`、`/root/CLM/checkpoints/CLM_v0.1-8B.pt`，只读挂载；不拷贝入镜像。
- 编译器固定在 **GCC 11**，避免原生环境 GCC 15 的 NVCC 构建错误；基于 NVIDIA CUDA 12.8.1 `devel` 镜像保证 nvcc 可用。

## 0. 停止旧的虚拟环境进程（需要人工确认）

```bash
ss -lntp | grep -E ':8090|:8700'
ps -ef | grep -E '[v]llm serve|[c]lm-serve'
nvidia-smi -i 3,4
```

如果是前台启动，在原终端分别按 Ctrl+C。若存在此前创建的专用 systemd 单元且属于这个项目：

```bash
systemctl stop clm-api.service clm-vllm.service
systemctl disable clm-api.service clm-vllm.service
```

如果已由前台终端退出，则无需 systemctl 操作。对存活的遗留进程，应核对 PID 和命令行后仅对其执行 `kill -TERM PID`，不要用 `pkill python` / `killall python`，不要影响 GPU 0–2。

## 1. 宿主机 NVIDIA Container Toolkit 检查

```bash
docker --version
docker info --format '{{json .Runtimes}}'
command -v nvidia-ctk || true
nvidia-smi --query-gpu=index,uuid,name,memory.total --format=csv
```

若 Toolkit 已配置，直接探测（**只允许 GPU 3、4**）：

```bash
docker run --rm --gpus '"device=3,4"' nvidia/cuda:12.8.1-base-ubuntu22.04 nvidia-smi -L
```

若报 `could not select device driver "" with capabilities [[gpu]]`，应由管理员安装 `nvidia-container-toolkit` 并用 `nvidia-ctk runtime configure --runtime=docker` 配置。该命令后 NVIDIA 官方要求重启 Docker daemon；**重启 Docker 会影响同服务器的其他容器，务必先由管理员安排维护窗口，特别是 GPU 0–2 的业务**。如果主机 `dnf` 的 `arm-OS` 仓库不可用，应修复包管理仓库或采用单位批准的离线 RPM，不要随意改动其他业务仓库。

官方说明：https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html

## 2. 复用 ModelScope 下载文件

```bash
ls -lh /root/CLM/models/Qwen3-8B/config.json
ls -lh /root/CLM/checkpoints/CLM_v0.1-8B.pt
```

如果尚未下载：

```bash
python3 -m pip install -U modelscope
modelscope download --model Qwen/Qwen3-8B --local_dir /root/CLM/models/Qwen3-8B
modelscope download --model Contrastive-LM/CLM-v0.1-8B CLM_v0.1-8B.pt --local_dir /root/CLM/checkpoints
```

已经存在时不需要重新下载。**镜像不复制模型权重**。

## 3. 解压部署包

把 `CLM_Docker_T4_Deployment.zip` 上传到服务器 `/root/CLM`，然后：

```bash
cd /root/CLM
python3 -m zipfile -e CLM_Docker_T4_Deployment.zip .
ls docker-deploy/
```

目录应是 `/root/CLM/docker-deploy`。如下载后目录名称不同，直接将本包中的 2 个 Dockerfile、`deploy.sh`、`test_clm.py` 放入 `/root/CLM/docker-deploy`。

## 4. 构建两个镜像

```bash
cd /root/CLM/docker-deploy
bash deploy.sh build
```

`deploy.sh build` 自动从 `/root/CLM` 复制 `src`、`pyproject.toml`、`README.md`（**不复制模型权重**）。

查看构建版本：

```bash
docker images | grep -E '^clm-(encoder|api)'
docker run --rm --entrypoint python3 clm-encoder:cu128 -c 'import torch, vllm; print("torch",torch.__version__, "cuda",torch.version.cuda,"vllm",vllm.__version__)'
docker run --rm --entrypoint python clm-api:cpu -c 'import torch,clm; print("torch",torch.__version__,"clm",clm.__file__)'
```

**不要期待 CPU-only CLM 镜像能运行 vLLM**：投影头服务无需 vLLM，本设计特意分离依赖。

## 5. 创建网络，启动编码器（仅 GPU 3、4）

```bash
cd /root/CLM/docker-deploy
bash deploy.sh gpu-test
bash deploy.sh start-encoder

docker logs -f clm-encoder
```

在第二个终端中确认：

```bash
curl -fsS http://127.0.0.1:8090/v1/models
docker exec clm-encoder nvidia-smi -L
docker exec clm-encoder python3 -c 'import torch; print("visible GPU count:", torch.cuda.device_count())'
docker inspect --format '{{json .HostConfig.DeviceRequests}}' clm-encoder
```

注意：`--gpus '"device=3,4"'` 指定宿主机**物理编号** 3、4；容器中的 CUDA 通常将它们重编号为逻辑 `cuda:0`、`cuda:1`。**不要在容器内部再写 `CUDA_VISIBLE_DEVICES=3,4`**，否则可能无卡可用。以宿主机和容器内的 GPU UUID 交叉验证实际对应关系；如果宿主机物理编号可能调整，可改用设备 UUID。

默认 `VLLM_ATTENTION_BACKEND=TRITON_ATTN`。若你实际已经在原生部署中确认其它 backend 更稳定，可先执行 `ATTENTION_BACKEND=FLASHINFER bash deploy.sh start-encoder`（只在尚未创建容器时）；若后端失败，应检查日志，不要在服务运行时修改配置。**不要选 `FLASH_ATTN`**：T4 不支持 FlashAttention 2。`FLASHINFER` 会在首批真实请求时 JIT 编译，GCC11 与 CUDA devel 镜像旨在规避之前的编译器问题。

## 6. 先实测编码器再启动 CLM

```bash
python3 - <<'PY'
import json, urllib.request, base64
url='http://127.0.0.1:8090/v1/embeddings'
payload={"model":"qwen3-8b","input":["Hello CLM", "Billing and refunds", "Engineering outages"],"encoding_format":"base64","truncate_prompt_tokens":2048}
req=urllib.request.Request(url,json.dumps(payload).encode(),headers={"Content-Type":"application/json"},method='POST')
with urllib.request.urlopen(req,timeout=300) as r:
    data=json.load(r)['data']
assert len(data)==3 and all(len(base64.b64decode(item['embedding']))//4==4096 for item in data)
print('Embedding batch: PASS, dimension=4096')
PY
```

此步只有 **HTTP 200、三条 4096 维、8090 进程存活** 才通过，`/v1/models` 成功还不够。

## 7. 启动 CPU CLM API

```bash
cd /root/CLM/docker-deploy
bash deploy.sh start-api
docker logs --tail 100 clm-api
curl -fsS http://127.0.0.1:8700/health
```

预期 `ok=true, embedder=true, models` 包含 `clm-latest`。此检查只验证编码器能连接，不等于 Rank 成功。

## 8. 执行端到端验收

```bash
cd /root/CLM/docker-deploy
python3 test_clm.py --repeat 5 --report /root/CLM/clm_docker_report.json
```

此脚本仅用 Python 标准库，包含七项检查：编码器模型列表、CLM 健康、单文本 4096 维、批量 4096 维、Rank 三候选排序、System One（noul/choice/score）、连续 Rank 与缓存命中。**只有 7/7 通过才能认定 CLM 端到端功能可用**。脚本会输出失败原因，并且退出状态非 0。其 `PASS` 只验证推理接口，不等于系统已实现生产级 HA、认证、驱动升级兼容或重启后运行验证。

另外检查物理 GPU 限制：

```bash
nvidia-smi --query-gpu=index,uuid,name,memory.used --format=csv
nvidia-smi --query-compute-apps=pid,process_name,gpu_uuid,used_gpu_memory --format=csv
docker inspect --format '{{json .HostConfig.DeviceRequests}}' clm-encoder
```

## 9. 查看容器、日志和自动重启

```bash
docker ps --filter name=clm-
docker logs --tail 100 clm-encoder
docker logs --tail 100 clm-api
docker stats clm-encoder clm-api --no-stream
docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' clm-encoder
docker inspect --format '{{.HostConfig.RestartPolicy.Name}}' clm-api
```

`--restart unless-stopped` 允许 Docker 在合适条件下自动恢复容器；两个容器采用独立的 json-file 日志大小/数量轮转限制（50MB×3、20MB×3），但仍应测试真实推理、重启场景及日志。只有镜像服务使用宿主机允许的 Docker 安全管控规则时才能采用该方式。

## 10. 浏览器访问

默认仅在宿主机回环接口发布 8700：

```powershell
ssh -N -L 8700:127.0.0.1:8700 root@你的服务器IP
```

Windows 浏览器打开 `http://127.0.0.1:8700/`。不要直接暴露未加鉴权的 8090/8700 服务到公网；对于 Docker 20.10.12 这样的老版本，不能仅依赖 `127.0.0.1` 绑定作为唯一网络安全边界，应配合宿主机防火墙、私有网络及必要的反向代理认证。

## 11. 停止、删除容器与回滚

```bash
# 只停止本 CLM 项目的容器
bash deploy.sh stop

# 若需要重建相同名称的两个容器，先确认它们确实属于本项目
docker ps -a --filter name=clm-
docker rm clm-api clm-encoder

# 如果需要完全移除专用网络（确认无其他用户）
docker network rm clm-net
```

上述动作不会删除宿主机的模型或 `.venv-clm-t4`，也不会停止 GPU 0–2 的业务容器。**不要执行 `docker system prune -a` 或重启 Docker daemon 作为日常清理。**

## 故障速查

| 提示 | 处置 |
|---|---|
| `could not select device driver "" with capabilities [[gpu]]` | 配置 NVIDIA Container Toolkit；重启 Docker 前安排维护窗口 |
| `Failed to find C compiler` | 镜像是否包含 gcc-11；查 `docker exec clm-encoder /usr/bin/gcc-11 --version` |
| `gcc versions later than 14 are not supported` | 核对容器内 `CC=/usr/bin/gcc-11` 和 `/usr/bin/g++-11`，以及 nvcc 实际 `-ccbin` |
| `Ninja build failed` | 看第一次真实 Embedding 时的 `docker logs clm-encoder`，保留底层编译错误 |
| `FlashAttention 2 only supported >= 8.0` | T4 是 SM75，不要强制 FLASH_ATTN；考虑 TRITON_ATTN 或 FLASHINFER |
| `EngineCore encountered an issue` / 400 | 服务端只给出了包装错误，真正原因在 encoder 容器的 Worker/EngineCore 堆栈 |
| `Connection refused` at 8090 | 先确认 encoder 是否仍 running/healthy、是否端口映射和网络正确 |
| `embedder:false` | 容器间访问 `http://clm-encoder:8090/v1/embeddings` 是否正常 |
| `OOM` | 核查 GPU3、4 是否独占可用，减少 `--gpu-memory-utilization`/`--max-num-seqs`/上下文参数 |
| `NCCL` | 检查 Docker GPU 透传、共享内存、两卡 peer-to-peer 链路，避免盲目关闭 NCCL 功能 |

**来源**：CLM GitHub README、官方源码；vLLM v0.11.2 安装/attention backend 文档；NVIDIA Container Toolkit 官方文档；NVIDIA CUDA 官方镜像。
