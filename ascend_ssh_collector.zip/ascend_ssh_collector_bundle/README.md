# 昇腾服务器 SSH 批量采集工具

## 适用范围

在一台管理服务器上，使用 SSH 访问已授权的目标服务器，自动采集：
- Linux 发行版、版本、内核、CPU 架构
- 昇腾 NPU 型号、健康状态、NPU 数量、驱动版本、npu-smi 版本
- 每张 NPU 的 PCIe Bus ID、HBM、AICore、温度、功率、相关进程
- Docker 客户端版本、服务端版本

支持继续更新当前包含 13 台服务器、104 张 NPU 的 Excel 工作簿。

## 1. 管理服务器安装依赖

```bash
python3 -m pip install openpyxl
```

管理服务器还需要安装 `ssh` 客户端；目标服务器需要能够通过 SSH 登录，并提供 `bash`、`npu-smi`、`docker`（如安装）。**目标机无需安装 Python**。

## 2. 配置 SSH

在管理服务器生成专用密钥：

```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519
```

由管理员将公钥加入每台目标机上**具有读取权限**的采集账号的 `~/.ssh/authorized_keys`，或使用：

```bash
ssh-copy-id ops@192.168.10.101
```

首次连接时通过可信渠道核对主机指纹，然后手动 SSH 登录一次，建立 `known_hosts` 记录：

```bash
ssh ops@192.168.10.101 hostname
```

本工具默认要求密钥免交互登录，且会**严格校验已记录的主机密钥**。不关闭主机指纹验证，不会在脚本或 Excel 中保存 SSH 密码。

## 3. 配置 hosts.txt

每行填写一个 `用户名@IP` 或 `用户名@主机名`，例如：

```text
ops@192.168.10.101
ops@192.168.10.102
```

不需要扫描网段；只采集自己有权限管理的设备。

## 4. 首次运行（沿用现有 13 台服务器台账）

```bash
python3 collect_ascend_inventory.py \
  --hosts hosts.txt \
  --base ascend_server_inventory_13_servers.xlsx \
  --output ascend_server_inventory.xlsx \
  --workers 4
```

Excel 包含「服务器汇总」「NPU设备明细」两张工作表，保留既有字段，自动增加新服务器。脚本按服务器名去重；重复采集会替换该服务器的 NPU 记录，避免重复。

## 5. 后续运行

可继续使用同一个输出文件（直接原位更新）：

```bash
python3 collect_ascend_inventory.py --hosts hosts.txt --output ascend_server_inventory.xlsx
```

也可用 `--base` 指定已有 Excel、`--output` 指定新的输出文件，以保留旧快照。建议定期备份 Excel。

## 6. 注意事项

- 同网段只说明网络位置相近，不能保证 SSH 端口可达；需要网络 ACL、防火墙、路由和账号权限均允许。
- 若非 root 用户无法查看某些 Docker 或 NPU 信息，会采集失败或获取 `N/A`。建议仅授权必要的只读访问权限。
- AICore 利用率、温度、功率、HBM 是**采集时刻的快照**，不代表持续负载或性能基准。
- 远程命令均为只读查询，不会执行 Docker 重启、驱动升级或服务变更。
- SSH 失败或解析失败不会删除旧台账；相关错误记入 `collect_errors.csv`，旧数据可能已经过时，应核对采集成功数量。
- 如 Excel 正被 WPS/Excel 打开，可能无法保存；运行前请关闭文件。
