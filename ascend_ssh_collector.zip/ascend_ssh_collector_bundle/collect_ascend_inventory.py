#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""通过 SSH 批量采集昇腾服务器，并按既有双工作表格式维护 Excel 台账。"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import copy
from datetime import datetime
import csv
from pathlib import Path
import re
import subprocess
import sys

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("缺少 openpyxl：请在采集服务器上执行 python3 -m pip install openpyxl")

SUMMARY = [
    '序号', '服务器名称', '操作系统', '系统版本', 'Linux内核版本', 'CPU架构',
    'NPU型号', 'NPU数量', '健康NPU数量', '驱动版本', 'npu-smi版本',
    'Docker客户端版本', 'Docker服务端版本', 'HBM总容量(MB)', 'HBM已使用(MB)',
    'HBM使用率', '平均AICore(%)', 'NPU总功率(W)', '运行进程', '备注',
]
DETAIL = [
    '序号', '服务器名称', 'NPU编号', 'Chip编号', 'NPU型号', '健康状态',
    'PCIe Bus ID', '功率(W)', '温度(℃)', 'AICore利用率(%)',
    'HBM已使用(MB)', 'HBM总容量(MB)', 'HBM使用率', '进程PID',
    '进程名称', '进程显存(MB)',
]

# bash 在每台目标服务器执行；不要求目标机安装 Python 或 openpyxl。
REMOTE_SH = r'''set +e
printf '%s\n' '___META_BEGIN___'
printf 'HOST='; hostname -s
printf 'OS_NAME='; ( . /etc/os-release; printf '%s\n' "${NAME:-unknown}" )
printf 'OS_VERSION='; ( . /etc/os-release; printf '%s\n' "${VERSION_ID:-unknown}" )
printf 'PRETTY_NAME='; ( . /etc/os-release; printf '%s\n' "${PRETTY_NAME:-unknown}" )
printf 'KERNEL='; uname -r
printf 'ARCH='; uname -m
printf 'DRIVER='; if [ -r /usr/local/Ascend/version.info ]; then sed -n 's/^version=//p' /usr/local/Ascend/version.info | head -n 1; else echo N/A; fi
printf 'DOCKER_CLIENT='; if command -v docker >/dev/null 2>&1; then docker --version 2>/dev/null | sed -n 's/^Docker version \([^, ]*\).*/\1/p'; else echo N/A; fi
printf 'DOCKER_SERVER='; if command -v docker >/dev/null 2>&1; then docker version --format '{{.Server.Version}}' 2>/dev/null || echo N/A; else echo N/A; fi
printf '%s\n' '___META_END___'
printf '%s\n' '___NPU_BEGIN___'
if command -v npu-smi >/dev/null 2>&1; then npu-smi info 2>&1
elif [ -x /usr/local/Ascend/tools/npu-smi ]; then /usr/local/Ascend/tools/npu-smi info 2>&1
else echo 'COLLECT_ERROR: npu-smi not found'; fi
printf '%s\n' '___NPU_END___'
'''


def parse_output(raw):
    meta_match = re.search(r'___META_BEGIN___\s*\n(.*?)\n___META_END___', raw, re.S)
    npu_match = re.search(r'___NPU_BEGIN___\s*\n(.*?)\n___NPU_END___', raw, re.S)
    if not meta_match or not npu_match:
        raise ValueError('远程输出不完整；请确认 SSH、bash、npu-smi 权限和连接稳定性')
    meta = {}
    for line in meta_match.group(1).splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            meta[key] = value.strip()
    if not meta.get('HOST'):
        raise ValueError('无法获取远程 hostname')
    # 既有台账将系统版本记为 '22.10U1 LTS'，与 PRETTY_NAME 保持一致。
    if (meta.get('PRETTY_NAME', '').endswith(' LTS') and
            meta.get('OS_VERSION') and not meta['OS_VERSION'].endswith(' LTS')):
        meta['OS_VERSION'] += ' LTS'
    npu_raw = npu_match.group(1)
    version_match = re.search(r'\bnpu-smi\s+([\d.]+)', npu_raw, re.I)
    version = version_match.group(1) if version_match else 'N/A'

    cards, active_idx, processes = {}, None, {}
    for line in npu_raw.splitlines():
        if not line.startswith('|') or not line.rstrip().endswith('|'):
            continue
        fields = [p.strip() for p in line.strip().strip('|').split('|')]
        if len(fields) < 3:
            continue
        # 设备主行：| 0 910B2 | OK | 125.4 43 0 / 0 |
        first = re.fullmatch(r'(\d+)\s+(\S+)', fields[0])
        if first and len(fields) == 3 and re.match(r'^(OK|Warning|Alarm|Fault|Critical|Unknown)\b', fields[1], re.I):
            values = re.match(r'([\d.]+)\s+(\d+)\s+', fields[2])
            if values:
                active_idx = int(first.group(1))
                cards[active_idx] = {
                    'id': active_idx, 'model': first.group(2), 'health': fields[1],
                    'power': float(values.group(1)), 'temp': int(values.group(2)),
                }
                continue
        # 设备第二行：| 0 | 0000:C1:00.0 | 66 0 / 0 62515/65536 |
        if (fields[0].isdigit() and len(fields) == 3 and
                re.fullmatch(r'[0-9a-fA-F:.]+', fields[1]) and active_idx in cards):
            match = re.match(r'(\d+)\s+\d+\s*/\s*\d+\s+(\d+)\s*/\s*(\d+)', fields[2])
            if match:
                cards[active_idx].update({
                    'chip': int(fields[0]), 'bus': fields[1],
                    'aicore': int(match.group(1)), 'used': int(match.group(2)),
                    'total': int(match.group(3)),
                })
                continue
        # 进程行：| 0 0 | 3196189 | VLLMWorker_TP | 57115 | ... |
        proc_id = re.fullmatch(r'(\d+)\s+(\d+)', fields[0])
        if proc_id and len(fields) >= 4 and fields[1].isdigit() and fields[3].isdigit():
            idx = int(proc_id.group(1))
            processes.setdefault(idx, []).append({
                'pid': fields[1], 'name': fields[2], 'mem': int(fields[3]),
            })

    usable = []
    for i in sorted(cards):
        c = cards[i]
        if not all(key in c for key in ('chip', 'bus', 'aicore', 'used', 'total')):
            continue
        procs = processes.get(i, [])
        c['pid'] = ','.join(p['pid'] for p in procs)
        c['proc_name'] = ','.join(dict.fromkeys(p['name'] for p in procs))
        c['proc_mem'] = sum(p['mem'] for p in procs) if procs else None
        usable.append(c)
    if not usable:
        raise ValueError('未解析出 NPU 设备记录；npu-smi 输出：' + npu_raw[:160].replace('\n', ' '))
    return meta, version, usable


def collect(target, timeout):
    cmd = [
        'ssh', '-T', '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
        '-o', 'ConnectTimeout=7', '-o', 'ServerAliveInterval=10',
        '-o', 'ServerAliveCountMax=2', target, 'bash -s',
    ]
    try:
        proc = subprocess.run(cmd, input=REMOTE_SH, text=True, capture_output=True, timeout=timeout)
        if proc.returncode:
            raise RuntimeError((proc.stderr or proc.stdout or 'SSH 返回非零状态').strip()[-700:])
        meta, version, cards = parse_output(proc.stdout)
        return target, meta, version, cards, None
    except (OSError, subprocess.TimeoutExpired, RuntimeError, ValueError) as ex:
        return target, None, None, None, str(ex)


def init_book():
    book = Workbook()
    s = book.active
    s.title = '服务器汇总'
    d = book.create_sheet('NPU设备明细')
    for ws, header in ((s, SUMMARY), (d, DETAIL)):
        ws.append(header)
        ws.freeze_panes = 'C2'
        ws.auto_filter.ref = f'A1:{get_column_letter(len(header))}1'
        ws.row_dimensions[1].height = 30
        for cell in ws[1]:
            cell.fill = PatternFill('solid', fgColor='164E63')
            cell.font = Font(color='FFFFFF', bold=True)
            cell.alignment = Alignment(horizontal='center', vertical='center')
        for col in range(1, len(header) + 1):
            ws.column_dimensions[get_column_letter(col)].width = 18
    s.column_dimensions['B'].width = 24
    s.column_dimensions['E'].width = 58
    s.column_dimensions['T'].width = 38
    d.column_dimensions['B'].width = 24
    d.column_dimensions['G'].width = 20
    return book


def styled_append(ws, values):
    source_row = ws.max_row
    dest_row = source_row + 1
    ws.append(values)
    if source_row > 1:
        for j in range(1, len(values) + 1):
            old = ws.cell(source_row, j)
            new = ws.cell(dest_row, j)
            if old.has_style:
                new._style = copy(old._style)
            if old.alignment:
                new.alignment = copy(old.alignment)
    ws.row_dimensions[dest_row].height = 21
    return dest_row


def match_sheet_headers(ws, required):
    headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]
    missing = set(required) - set(headers)
    if missing:
        raise ValueError(f'工作表 {ws.title} 缺少表头：{sorted(missing)}')
    return {str(name): i for i, name in enumerate(headers)}


def row_values(mapping, data):
    values = [None] * len(mapping)
    for name, value in data.items():
        if name in mapping:
            values[mapping[name]] = value
    return values


def update_book(book, results):
    main, detail = book['服务器汇总'], book['NPU设备明细']
    main_map = match_sheet_headers(main, SUMMARY)
    detail_map = match_sheet_headers(detail, DETAIL)
    by_name = {main.cell(r, main_map['服务器名称'] + 1).value: r
               for r in range(2, main.max_row + 1)
               if main.cell(r, main_map['服务器名称'] + 1).value}
    for target, meta, npu_version, cards, error in results:
        if error:
            continue
        hostname = meta['HOST']
        used = sum(c['used'] for c in cards)
        total = sum(c['total'] for c in cards)
        names = sorted({c['model'] for c in cards})
        procs = sorted({c['proc_name'] for c in cards if c['proc_name']})
        note = f'采集成功：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}；SSH目标：{target}'
        if meta.get('DOCKER_SERVER') not in (meta.get('DOCKER_CLIENT'), None):
            note += '；Docker客户端和服务端版本不同，需核实'
        entry = {
            '服务器名称': hostname, '操作系统': meta.get('OS_NAME'),
            '系统版本': meta.get('OS_VERSION'), 'Linux内核版本': meta.get('KERNEL'),
            'CPU架构': meta.get('ARCH'), 'NPU型号': ','.join(names),
            'NPU数量': len(cards), '健康NPU数量': sum(c['health'].upper() == 'OK' for c in cards),
            '驱动版本': meta.get('DRIVER'), 'npu-smi版本': npu_version,
            'Docker客户端版本': meta.get('DOCKER_CLIENT'),
            'Docker服务端版本': meta.get('DOCKER_SERVER'),
            'HBM总容量(MB)': total, 'HBM已使用(MB)': used,
            '平均AICore(%)': round(sum(c['aicore'] for c in cards) / len(cards), 2),
            'NPU总功率(W)': round(sum(c['power'] for c in cards), 1),
            '运行进程': ', '.join(procs), '备注': note,
        }
        if hostname in by_name:
            row = by_name[hostname]
            for key, val in entry.items():
                if key == '备注':  # 不覆盖用户在旧台账中填写的备注
                    continue
                main.cell(row, main_map[key] + 1, val)
        else:
            entry['序号'] = len(by_name) + 1
            # 原台账有已格式化的预留空白行，优先填入，不跳过。
            row = next((r for r in range(2, main.max_row + 1)
                        if not main.cell(r, main_map['服务器名称'] + 1).value), None)
            if row is None:
                row = styled_append(main, row_values(main_map, entry))
            else:
                for key, val in entry.items():
                    main.cell(row, main_map[key] + 1, val)
            by_name[hostname] = row
        hbm_col = get_column_letter(main_map['HBM已使用(MB)'] + 1)
        total_col = get_column_letter(main_map['HBM总容量(MB)'] + 1)
        percent_cell = main.cell(row, main_map['HBM使用率'] + 1)
        percent_cell.value = f'=IFERROR({hbm_col}{row}/{total_col}{row},0)'
        percent_cell.number_format = '0.00%'

        # 先删除此服务器过去的 NPU 快照，再写入本次数据，避免重复。
        target_col = detail_map['服务器名称'] + 1
        for r in range(detail.max_row, 1, -1):
            if detail.cell(r, target_col).value == hostname:
                detail.delete_rows(r)
        for c in cards:
            entry = {
                '序号': detail.max_row, '服务器名称': hostname,
                'NPU编号': c['id'], 'Chip编号': c['chip'],
                'NPU型号': c['model'], '健康状态': c['health'],
                'PCIe Bus ID': c['bus'], '功率(W)': c['power'],
                '温度(℃)': c['temp'], 'AICore利用率(%)': c['aicore'],
                'HBM已使用(MB)': c['used'], 'HBM总容量(MB)': c['total'],
                '进程PID': c['pid'], '进程名称': c['proc_name'],
                '进程显存(MB)': c['proc_mem'],
            }
            dr = styled_append(detail, row_values(detail_map, entry))
            du = get_column_letter(detail_map['HBM已使用(MB)'] + 1)
            dt = get_column_letter(detail_map['HBM总容量(MB)'] + 1)
            ratio = detail.cell(dr, detail_map['HBM使用率'] + 1)
            ratio.value = f'=IFERROR({du}{dr}/{dt}{dr},0)'
            ratio.number_format = '0.00%'
    # 删除旧快照后，重排明细序号及全部 HBM 公式，避免旧公式指向已删除行。
    du = get_column_letter(detail_map['HBM已使用(MB)'] + 1)
    dt = get_column_letter(detail_map['HBM总容量(MB)'] + 1)
    for r in range(2, detail.max_row + 1):
        detail.cell(r, detail_map['序号'] + 1, r - 1)
        ratio = detail.cell(r, detail_map['HBM使用率'] + 1)
        ratio.value = f'=IFERROR({du}{r}/{dt}{r},0)'
        ratio.number_format = '0.00%'
    for ws in (main, detail):
        ws.auto_filter.ref = f'A1:{get_column_letter(ws.max_column)}{ws.max_row}'
        for table in ws.tables.values():
            table.ref = ws.auto_filter.ref
        ws.freeze_panes = 'C2'


def main():
    ap = argparse.ArgumentParser(description='SSH 批量采集昇腾服务器，并更新 Excel 台账')
    ap.add_argument('--hosts', default='hosts.txt', help='SSH 目标清单，例如 ops@10.10.0.1')
    ap.add_argument('--base', help='已有 Excel 台账；新记录追加，同名服务器覆盖最新采集数据')
    ap.add_argument('--output', default='ascend_server_inventory.xlsx', help='输出文件名')
    ap.add_argument('--workers', type=int, default=4, help='同时采集的服务器数量（默认 4）')
    ap.add_argument('--timeout', type=int, default=60, help='单台服务器采集超时时间（秒）')
    args = ap.parse_args()
    hosts_path = Path(args.hosts)
    if not hosts_path.is_file():
        sys.exit(f'找不到服务器清单：{hosts_path}')
    hosts = list(dict.fromkeys(x.strip() for x in hosts_path.read_text(encoding='utf-8-sig').splitlines()
                               if x.strip() and not x.lstrip().startswith('#')))
    if not hosts:
        sys.exit('hosts.txt 中没有 SSH 目标，请每行填写 user@IP 或 user@hostname')
    if any(re.search(r'\s', h) or h.startswith('-') for h in hosts):
        sys.exit('hosts.txt 存在非法 SSH 目标，需使用 user@IP 或 user@hostname')
    if args.base:
        book = load_workbook(args.base)
    elif Path(args.output).is_file():
        book = load_workbook(args.output)
    else:
        book = init_book()
    if not {'服务器汇总', 'NPU设备明细'} <= set(book.sheetnames):
        sys.exit('已有 Excel 缺少「服务器汇总」或「NPU设备明细」工作表')

    results = []
    with ThreadPoolExecutor(max_workers=max(1, min(16, args.workers))) as executor:
        for item in as_completed([executor.submit(collect, h, args.timeout) for h in hosts]):
            result = item.result()
            results.append(result)
            if result[-1]:
                print(f'[FAIL] {result[0]}: {result[-1]}')
            else:
                print(f'[ OK ] {result[0]} -> {result[1]["HOST"]}: {len(result[3])} NPU')
    update_book(book, results)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    if args.base and Path(args.base).resolve() == out.resolve():
        sys.exit('安全限制：--base 和 --output 必须使用不同路径，避免误覆盖原台账')
    book.save(out)
    failures = [(h, err) for h, _, _, _, err in results if err]
    if failures:
        errors_path = out.with_name('collect_errors.csv')
        with errors_path.open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(['采集时间', 'SSH目标', '错误'])
            for h, err in failures:
                w.writerow([datetime.now().isoformat(timespec='seconds'), h, err])
        print(f'失败明细：{errors_path}')
    print(f'Excel 已生成：{out.resolve()}；成功 {len(hosts) - len(failures)}/{len(hosts)} 台')


if __name__ == '__main__':
    main()
