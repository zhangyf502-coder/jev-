# CLM OpenAI Adapter V1.0

为 CLM (`Contrastive-LM/CLM`) 添加 OpenAI 风格的模型列表、Chat Completions 和 SSE 接口。

**重要**：CLM 是有候选集的决策/评分模型，而不是聊天文本生成模型。本适配器只做协议转换，不伪造自由文本生成。

## 现有服务

- `clm-api`: `127.0.0.1:8700`，原始 CLM `/v1/systemone` `/v1/rank`；不改动
- `clm-encoder`: `127.0.0.1:8090`，原始 vLLM encoder；不改动
- 本适配服务：`127.0.0.1:8710`，OpenAI 风格对外端点

## Linux Docker 上线

```bash
# 在此项目目录中
cp .env.example .env
# 编辑 .env：把 ADAPTER_API_KEY 改为长随机秘钥
# 可以用 openssl rand -hex 32 生成密钥

docker compose up -d --build
docker logs -f clm-openai-adapter

# 验证原始 CLM
auth_header='' # 若 CLM 开启鉴权，则自行加 CLM Bearer header
curl -fsS http://127.0.0.1:8700/health

# 验证适配层
set -a; . ./.env; set +a
curl -sS http://127.0.0.1:8710/v1/models \
  -H "Authorization: Bearer $ADAPTER_API_KEY"
```

为什么使用 `network_mode: host`：现有 CLM 绑定在宿主机 `127.0.0.1:8700`，普通 Docker bridge 内的 `127.0.0.1` 是容器自己，无法访问现有的宿主机本地服务。Linux host 模式不需重建 CLM 容器。**该容器只在宿主机 `127.0.0.1:8710` 监听**；远程聚合平台需要一层 HTTPS 反向代理（并配置防火墙或访问白名单），或安全隧道。不要裸开放到公网。

当前服务 Dockerfile 使用 CPU 模式的纯 HTTP 协议转换，无需 GPU。

## 聚合平台参数

| 字段 | 值 |
|---|---|
| 接口类型 | OpenAI-compatible Chat Completions |
| Base URL | `http://127.0.0.1:8710/v1`（聚合平台与 CLM 同一台主机时） |
| API Key | `.env` 中的 `ADAPTER_API_KEY` |
| Model ID | `clm-latest`，也可使用 CLM 返回的其他模型，例如 `clm-raw` |
| 接口 | `GET /v1/models`、`GET /v1/models/{id}` 和 `POST /v1/chat/completions` |

## 标准文字选择题输入

```bash
curl -sS http://127.0.0.1:8710/v1/chat/completions \
  -H "Authorization: Bearer $ADAPTER_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"model":"clm-latest","stream":false,"messages":[{"role":"user","content":"问题：客户重复扣款应由哪个部门处理？\nA. 财务部门\nB. 技术支持"}]}'
```

返回标准 OpenAI `choices[0].message.content`，内容只能是候选项标签，例如 `A`，不是开放式回答。附加 `clm_metadata.decision.probabilities` 保留 CLM 决策概率。

## JSON 专业决策输入（推荐）

最后一条 user message 的 `content` 放入 JSON 字符串，可避免误解析：

```json
{
  "task": "choice",
  "state": "客户反映账单重复扣款，要求退款",
  "question": "下一步交给哪个团队？",
  "options": {
    "A": "账务与退款处理团队",
    "B": "系统错误排查团队"
  }
}
```

它会转成 CLM 的 `/v1/systemone`：

```json
{
  "model": "clm-latest",
  "state": "客户反映账单重复扣款，要求退款",
  "questions": {
    "decision": {
      "type": "choice",
      "instructions": "下一步交给哪个团队？",
      "criteria": {"A": "账务与退款处理团队", "B": "系统错误排查团队"}
    }
  },
  "temperature": 1.0
}
```

- `task=choice`：选项字典或字符串数组；返回最优标签。
- `task=rank`：同样给出 options；使用 CLM `/v1/rank`；返回最优标签。
- `task=noul`：仅需要 `question` 和可选 `state`、`criteria`，返回 `true` 或 `false`。
- `task=score`：需要 `criteria` 为有序评分描述列表，返回浮点分值。
- `response_format: {"type":"json_object"}`：把完整决策、概率和说明以 JSON **字符串** 放入 `message.content`。
- `stream: true`：返回符合 OpenAI SSE 形式的结果，但它是 CLM 返回后模拟的几个消息块，**不是逐 Token 流式生成**。
- 不支持自由聊天、tool calls、多模态或 embeddings 透传；这些能力需显式报错。
- `usage.prompt_tokens/completion_tokens/total_tokens` 固定 0，因为 CLM 不产生文本 Token，而且其 `input_tokens` 仅统计缓存未命中的编码 Token；CLM 原始计费字段在 `clm_metadata.backend_usage` 中。

### Python OpenAI SDK 快速测试

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8710/v1", api_key="<ADAPTER_API_KEY>")
resp = client.chat.completions.create(
    model="clm-latest",
    messages=[{"role": "user", "content": "问题：2+2 等于多少？\nA. 4\nB. 5"}],
)
print(resp.choices[0].message.content)
```

## 安全说明和边界

1. `ADAPTER_API_KEY` 必须设置，未配置时接口返回 503；不要硬编码实际密钥到代码或 Git。
2. 外部聚合平台应通过 HTTPS + 白名单/零信任通道访问，不要暴露 8700/8090。
3. HTTP 协议层兼容不代表语义能力等同于 OpenAI 通用 LLM；开放式聊天请求返回 HTTP 400。
4. 暂不支持 `/v1/completions`、`/v1/responses`、`/v1/embeddings`、tool calling、图像和音频输入。
5. 如果平台健康检查强制生成自由文本，平台可能仍认为模型不可用；需要配置为选择题探针。
6. 对关键决策建议使用 JSON 输入，明确定义候选项；同题同模型做直连 vs 转换的一致性测试。

## 本地离线测试

```bash
pip install -r requirements.txt pytest
pytest -q
```

测试用本地 ASGI 模拟原始 CLM 返回；不对你的 T4 主机做远程操作，部署后再做真实请求验收。
