"""OpenAI Chat Completions compatibility adapter for CLM's System One / Rank API.

CLM is a *decision model*. This adapter does not provide open-ended generation.
Use a JSON task in the last user message or a question followed by labeled options.
"""
from __future__ import annotations

import hmac
import json
import math
import os
import re
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastapi import FastAPI, Header, Request
from fastapi.responses import JSONResponse, StreamingResponse

CLM_URL = os.getenv("CLM_URL", "http://127.0.0.1:8700").rstrip("/")
ADAPTER_API_KEY = os.getenv("ADAPTER_API_KEY", "")
CLM_API_KEY = os.getenv("CLM_API_KEY", "")
CLM_TIMEOUT_SECONDS = float(os.getenv("CLM_TIMEOUT_SECONDS", "120"))
MODEL_OWNER = "clm"
# One labeled option per line; deliberately require two or more options.
OPTION_RE = re.compile(r"^\s*([A-Z]|[1-9][0-9]?)\s*[.．、):：）-]\s*(\S.*)$")
QUESTION_RE = re.compile(r"^\s*(?:问题|题目|question|q)\s*[:：]\s*(.+)$", re.I)


class ApiError(Exception):
    def __init__(self, status: int, message: str, *, code: str = "invalid_request_error") -> None:
        super().__init__(message)
        self.status = status
        self.message = message
        self.code = code


def error_response(status: int, message: str, code: str = "invalid_request_error") -> JSONResponse:
    return JSONResponse(status_code=status, content={
        "error": {"message": message, "type": code, "param": None, "code": code}
    })


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.backend = httpx.AsyncClient(
        base_url=CLM_URL,
        timeout=httpx.Timeout(CLM_TIMEOUT_SECONDS),
        trust_env=False,  # Avoid unexpectedly proxying local CLM traffic.
    )
    try:
        yield
    finally:
        await app.state.backend.aclose()


app = FastAPI(title="CLM OpenAI Compatibility Adapter", version="1.0.0", lifespan=lifespan)


@app.exception_handler(ApiError)
async def api_error_handler(_req: Request, exc: ApiError):
    return error_response(exc.status, exc.message, exc.code)


def authenticate(authorization: str | None) -> None:
    if not ADAPTER_API_KEY:
        # Fail closed unless the operator configures a key.
        raise ApiError(503, "ADAPTER_API_KEY is not configured", code="configuration_error")
    expected = f"Bearer {ADAPTER_API_KEY}"
    if not authorization or not hmac.compare_digest(authorization, expected):
        raise ApiError(401, "Invalid API key", code="authentication_error")


async def upstream(request: Request, method: str, path: str, payload: dict | None = None) -> dict:
    headers = {"Authorization": f"Bearer {CLM_API_KEY}"} if CLM_API_KEY else {}
    try:
        client: httpx.AsyncClient = request.app.state.backend
        response = await client.request(method, path, json=payload, headers=headers)
    except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError) as exc:
        raise ApiError(502, f"CLM backend unavailable: {type(exc).__name__}", code="bad_gateway") from exc
    if not response.is_success:
        detail = response.text[:600]
        try:
            body = response.json()
            detail = str(body.get("detail", body.get("error", detail)))[:600]
        except (ValueError, AttributeError):
            pass
        # 4xx caused by invalid CLM requests can be corrected by the client.
        status = response.status_code if response.status_code in (400, 422) else 502
        raise ApiError(status, f"CLM backend returned HTTP {response.status_code}: {detail}",
                       code="backend_error")
    try:
        return response.json()
    except ValueError as exc:
        raise ApiError(502, "CLM backend returned invalid JSON", code="bad_gateway") from exc


def text_from_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for part in content:
            if not isinstance(part, dict) or part.get("type") != "text" or not isinstance(part.get("text"), str):
                raise ApiError(400, "Only text message content is supported (no images, audio or files)")
            parts.append(part["text"])
        return "\n".join(parts)
    raise ApiError(400, "messages[].content must be text or text parts")


def parse_task(messages: Any) -> dict:
    if not isinstance(messages, list) or not messages:
        raise ApiError(400, "messages must be a non-empty array")
    normalized = []
    for msg in messages:
        if not isinstance(msg, dict) or msg.get("role") not in {"system", "developer", "user", "assistant"}:
            raise ApiError(400, "Unsupported message role")
        normalized.append((msg["role"], text_from_content(msg.get("content"))))
    if normalized[-1][0] != "user":
        raise ApiError(400, "The last message must be a user decision request")
    last_text = normalized[-1][1].strip()
    prior = "\n\n".join(f"{role}: {content}" for role, content in normalized[:-1] if content)
    if not last_text:
        raise ApiError(400, "User message cannot be empty")

    # Explicit JSON, optionally inside a fenced code block.
    candidate = last_text
    fenced = re.fullmatch(r"```(?:json)?\s*\n(.*?)\n```", candidate, flags=re.S | re.I)
    if fenced:
        candidate = fenced.group(1)
    task = None
    try:
        obj = json.loads(candidate)
        if isinstance(obj, dict):
            task = obj
    except ValueError:
        pass
    if task is not None:
        task_type = task.get("task", task.get("type", "choice"))
        if task_type not in ("choice", "noul", "score", "rank"):
            raise ApiError(400, "task must be choice, noul, score, or rank")
        state = task.get("state", "")
        if prior:
            # Keep object/array state readable without injecting raw JSON syntax into CLM.
            if isinstance(state, str):
                state = prior + "\n\n" + state if state else prior
            else:
                state = {"conversation": prior, "state": state}
        question = task.get("question", task.get("instructions", ""))
        if not isinstance(question, str) or not question.strip():
            raise ApiError(400, "JSON tasks require a non-empty question")
        if task_type in ("choice", "rank"):
            options = task.get("options", task.get("criteria"))
            if isinstance(options, list):
                if len(options) < 2 or len(options) > 26 or not all(isinstance(v, str) and v for v in options):
                    raise ApiError(400, "options list requires 2..26 non-empty strings")
                options = {chr(65 + i): v for i, v in enumerate(options)}
            if not isinstance(options, dict) or len(options) < 2 or not all(
                isinstance(k, str) and k and isinstance(v, str) and v for k, v in options.items()
            ):
                raise ApiError(400, "options must map at least two labels to non-empty descriptions")
            return {"kind": task_type, "state": state, "question": question, "options": options}
        if task_type == "score":
            criteria = task.get("criteria")
            if not isinstance(criteria, list) or len(criteria) < 2:
                raise ApiError(400, "score task requires at least two ordered criteria levels")
            return {"kind": "score", "state": state, "question": question, "criteria": criteria}
        criteria = task.get("criteria")
        if criteria is not None and (not isinstance(criteria, dict) or not set(criteria) <= {"true", "false"}):
            raise ApiError(400, "noul criteria must contain only true/false descriptions")
        return {"kind": "noul", "state": state, "question": question, "criteria": criteria}

    # Simple plain-text multiple-choice input.
    options: dict[str, str] = {}
    non_option: list[str] = []
    question = None
    for line in last_text.splitlines():
        opt = OPTION_RE.match(line)
        if opt:
            label, description = opt.groups()
            if label in options:
                raise ApiError(400, f"Duplicate option: {label}")
            options[label] = description.strip()
        elif line.strip():
            q = QUESTION_RE.match(line)
            if q:
                question = q.group(1).strip()
            else:
                non_option.append(line.strip())
    if len(options) < 2:
        raise ApiError(400, "CLM is a decision model. Supply labeled options (A. ... / B. ...) or a JSON decision task")
    if not question and non_option:
        question = non_option.pop()  # Typically the final non-option line is the question.
    if not question:
        raise ApiError(400, "Please include a question before the options")
    state = "\n\n".join(v for v in [prior, "\n".join(non_option)] if v)
    return {"kind": "choice", "state": state, "question": question, "options": options}


def format_answer(kind: str, data: dict, task: dict, json_mode: bool) -> tuple[str, dict]:
    if kind == "rank":
        ranked = data.get("ranked")
        if not isinstance(ranked, list) or not ranked:
            raise ApiError(502, "CLM /v1/rank returned no rankings", code="bad_gateway")
        best = ranked[0]
        # Label may be mapped back from the option description.
        labels = list(task["options"])
        descs = list(task["options"].values())
        label = labels[descs.index(best["candidate"])] if best.get("candidate") in descs else best.get("candidate")
        result = {"task": kind, "choice": label, "candidate": best.get("candidate"), "ranked": ranked}
        return (json.dumps(result, ensure_ascii=False) if json_mode else str(label)), result
    answers = data.get("answers")
    if not isinstance(answers, dict) or not isinstance(answers.get("decision"), dict):
        raise ApiError(502, "CLM /v1/systemone returned no decision answer", code="bad_gateway")
    answer = answers["decision"]
    if kind == "choice":
        key = answer.get("choice")
        if key not in task["options"]:
            raise ApiError(502, "CLM returned an unknown choice", code="bad_gateway")
        result = {"task": kind, "choice": key, "description": task["options"][key],
                  "confidence": answer.get("confidence"), "probabilities": answer.get("probabilities")}
        output = str(key)
    elif kind == "noul":
        probability = answer.get("noul")
        if not isinstance(probability, (int, float)):
            raise ApiError(502, "CLM returned an invalid noul", code="bad_gateway")
        result = {"task": kind, "decision": bool(probability >= .5), "probability_true": probability}
        output = "true" if probability >= .5 else "false"
    else:
        value = answer.get("score")
        if not isinstance(value, (int, float)):
            raise ApiError(502, "CLM returned an invalid score", code="bad_gateway")
        result = {"task": kind, "score": value, "legend": answer.get("legend"),
                  "probabilities": answer.get("probabilities")}
        output = str(value)
    return (json.dumps(result, ensure_ascii=False) if json_mode else output), result


def sse_chunk(completion_id: str, model: str, created: int, delta: dict,
              finish_reason: str | None = None, usage: dict | None = None) -> str:
    body = {"id": completion_id, "object": "chat.completion.chunk", "created": created,
            "model": model, "choices": [{"index": 0, "delta": delta, "finish_reason": finish_reason}]}
    if usage is not None:
        body["usage"] = usage
    return "data: " + json.dumps(body, ensure_ascii=False) + "\n\n"


@app.get("/health")
async def health(request: Request):
    try:
        backend = await upstream(request, "GET", "/health")
        good = bool(backend.get("ok")) and bool(backend.get("embedder"))
        return JSONResponse(status_code=200 if good else 503, content={"ok": good, "clm": backend})
    except ApiError:
        return JSONResponse(status_code=503, content={"ok": False, "clm": "unreachable"})


@app.get("/v1/models")
async def models(request: Request, authorization: str | None = Header(default=None)):
    authenticate(authorization)
    result = await upstream(request, "GET", "/v1/models")
    entries = result.get("models", [])
    if not isinstance(entries, list):
        raise ApiError(502, "CLM model list is invalid", code="bad_gateway")
    return {"object": "list", "data": [
        {"id": model["name"], "object": "model", "created": 0, "owned_by": MODEL_OWNER}
        for model in entries if isinstance(model, dict) and isinstance(model.get("name"), str)
    ]}


@app.get("/v1/models/{model_id}")
async def model_detail(model_id: str, request: Request, authorization: str | None = Header(default=None)):
    authenticate(authorization)
    result = await upstream(request, "GET", "/v1/models")
    for item in result.get("models", []):
        if isinstance(item, dict) and item.get("name") == model_id:
            return {"id": model_id, "object": "model", "created": 0, "owned_by": MODEL_OWNER}
    raise ApiError(404, f"Model not found: {model_id}", code="model_not_found")


@app.post("/v1/chat/completions")
async def chat_completions(request: Request, authorization: str | None = Header(default=None)):
    authenticate(authorization)
    try:
        body = await request.json()
    except ValueError as exc:
        raise ApiError(400, "Request body must be JSON") from exc
    if not isinstance(body, dict):
        raise ApiError(400, "Request must be a JSON object")
    model = body.get("model")
    if not isinstance(model, str) or not model.strip():
        raise ApiError(400, "model is required")
    if body.get("tools") or body.get("functions") or body.get("tool_choice") not in (None, "none", "auto"):
        raise ApiError(400, "Tool calls are not supported by the CLM adapter")
    if body.get("n", 1) != 1:
        raise ApiError(400, "Only n=1 is supported")
    fmt = body.get("response_format") or {}
    if not isinstance(fmt, dict) or fmt.get("type", "text") not in ("text", "json_object"):
        raise ApiError(400, "Only text and json_object response formats are supported")
    json_mode = fmt.get("type") == "json_object"
    temperature = body.get("temperature", 1.0)
    if not isinstance(temperature, (float, int)) or not math.isfinite(temperature) or not 0 <= temperature <= 100:
        raise ApiError(400, "temperature must be between 0 and 100")
    # OpenAI clients routinely use 0 to mean deterministic output; CLM requires >0.
    clm_temperature = max(float(temperature), 0.01)
    task = parse_task(body.get("messages"))
    kind = task["kind"]
    if kind == "rank":
        result = await upstream(request, "POST", "/v1/rank", {
            "model": model, "context": task["state"], "question": task["question"],
            "answers": list(task["options"].values()), "temperature": clm_temperature,
        })
    else:
        question = {"type": kind, "instructions": task["question"]}
        if kind == "choice":
            question["criteria"] = task["options"]
        elif kind == "score":
            question["criteria"] = task["criteria"]
        elif task.get("criteria") is not None:
            question["criteria"] = task["criteria"]
        result = await upstream(request, "POST", "/v1/systemone", {
            "model": model, "state": task["state"], "questions": {"decision": question},
            "temperature": clm_temperature,
        })
    output, decision_meta = format_answer(kind, result, task, json_mode)
    now = int(time.time())
    uid = "chatcmpl-" + uuid.uuid4().hex
    # CLM counts cache-miss encoder tokens, not OpenAI prompt or completion tokens.
    # Returning zeros is deliberate: never mislabel the backend's metering as tokens generated.
    usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    if not body.get("stream", False):
        return {
            "id": uid, "object": "chat.completion", "created": now, "model": model,
            "choices": [{"index": 0, "message": {"role": "assistant", "content": output},
                         "logprobs": None, "finish_reason": "stop"}],
            "usage": usage,
            "clm_metadata": {"decision": decision_meta, "backend_usage": result.get("usage")},
        }

    async def events():
        # This is a *synthetic*, single-result stream. CLM does not generate tokens.
        yield sse_chunk(uid, model, now, {"role": "assistant", "content": ""})
        yield sse_chunk(uid, model, now, {"content": output})
        yield sse_chunk(uid, model, now, {}, finish_reason="stop")
        if (body.get("stream_options") or {}).get("include_usage"):
            tail = {"id": uid, "object": "chat.completion.chunk", "created": now,
                    "model": model, "choices": [], "usage": usage}
            yield "data: " + json.dumps(tail, ensure_ascii=False) + "\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(events(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})
