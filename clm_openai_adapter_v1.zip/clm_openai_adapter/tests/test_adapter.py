"""Offline contract tests for the CLM OpenAI adapter (no GPU/backend needed)."""
import asyncio
import json
from pathlib import Path
import sys

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app as adapter


async def request_case(body=None, *, endpoint="/v1/chat/completions", method="POST", auth=True):
    captured = []

    def fake_backend(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/health":
            return httpx.Response(200, json={"ok": True, "embedder": True})
        if request.url.path == "/v1/models":
            return httpx.Response(200, json={"models": [{"name": "clm-latest"}, {"name": "clm-raw"}]})
        sent = json.loads(request.content)
        captured.append((request.url.path, sent))
        if request.url.path == "/v1/rank":
            return httpx.Response(200, json={"model": sent["model"], "ranked": [
                {"rank": 1, "candidate": sent["answers"][0], "prob": 0.95},
                {"rank": 2, "candidate": sent["answers"][1], "prob": 0.05},
            ]})
        if request.url.path == "/v1/systemone":
            question = sent["questions"]["decision"]
            kind = question["type"]
            if kind == "choice":
                label = list(question["criteria"])[0]
                answer = {"type": kind, "choice": label, "probabilities": {label: 0.9}, "confidence": 0.8}
            elif kind == "score":
                answer = {"type": kind, "score": 1.7, "legend": {"0": "Bad", "1": "Good"}}
            else:
                answer = {"type": kind, "noul": 0.7}
            return httpx.Response(200, json={"model": sent["model"],
                                               "answers": {"decision": answer},
                                               "usage": {"input_tokens": 12, "billing_units": 1}})
        return httpx.Response(404)

    backend = httpx.AsyncClient(base_url="http://clm.test", transport=httpx.MockTransport(fake_backend))
    adapter.app.state.backend = backend
    adapter.ADAPTER_API_KEY = "test-key"
    transport = httpx.ASGITransport(app=adapter.app)
    async with backend, httpx.AsyncClient(base_url="http://adapter.test", transport=transport) as client:
        r = await client.request(method, endpoint, json=body, headers={"Authorization": "Bearer test-key"} if auth else {})
        return r, captured


def test_models():
    r, calls = asyncio.run(request_case(endpoint="/v1/models", method="GET"))
    assert r.status_code == 200
    assert r.json()["data"][0]["id"] == "clm-latest"
    assert r.json()["object"] == "list"
    assert not calls


def test_choice_plain_text():
    body = {"model": "clm-latest", "messages": [{"role": "user", "content": "问题：哪个部门处理退款？\nA. 财务\nB. 技术"}]}
    r, captured = asyncio.run(request_case(body))
    assert r.status_code == 200, r.text
    assert r.json()["choices"][0]["message"]["content"] == "A"
    sent = captured[0][1]
    assert captured[0][0] == "/v1/systemone"
    assert sent["questions"]["decision"] == {
        "type": "choice", "instructions": "哪个部门处理退款？", "criteria": {"A": "财务", "B": "技术"}
    }
    assert r.json()["clm_metadata"]["backend_usage"]["input_tokens"] == 12
    assert r.json()["usage"]["prompt_tokens"] == 0


def test_json_rank_and_json_mode():
    task = {"task": "rank", "state": "用户投诉", "question": "如何处理？", "options": ["退款", "技术处理"]}
    body = {"model": "clm-raw", "response_format": {"type": "json_object"},
            "messages": [{"role": "user", "content": json.dumps(task, ensure_ascii=False)}]}
    r, calls = asyncio.run(request_case(body))
    assert r.status_code == 200, r.text
    obj = json.loads(r.json()["choices"][0]["message"]["content"])
    assert obj["choice"] == "A"
    assert calls[0][0] == "/v1/rank"
    assert calls[0][1]["answers"] == ["退款", "技术处理"]


def test_stream():
    body = {"model": "clm-latest", "stream": True, "stream_options": {"include_usage": True},
            "messages": [{"role": "user", "content": "问题：选择哪项？\nA. 第一\nB. 第二"}]}
    r, _ = asyncio.run(request_case(body))
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("text/event-stream")
    assert "chat.completion.chunk" in r.text
    assert '"content": "A"' in r.text
    assert 'data: [DONE]' in r.text
    assert '"choices": []' in r.text


def test_open_ended_chat_rejected():
    body = {"model": "clm-latest", "messages": [{"role": "user", "content": "请写一首诗"}]}
    r, calls = asyncio.run(request_case(body))
    assert r.status_code == 400
    assert not calls
    assert "decision model" in r.json()["error"]["message"]


def test_authentication_required():
    r, calls = asyncio.run(request_case(endpoint="/v1/models", method="GET", auth=False))
    assert r.status_code == 401
    assert not calls


def test_noul_and_score():
    for task_type, criteria, expected in [("noul", None, "true"), ("score", ["Bad", "Good"], "1.7")]:
        task = {"task": task_type, "state": "例子", "question": "判断一下"}
        if criteria:
            task["criteria"] = criteria
        body = {"model": "clm-latest", "messages": [{"role": "user", "content": json.dumps(task)}]}
        r, calls = asyncio.run(request_case(body))
        assert r.status_code == 200, r.text
        assert r.json()["choices"][0]["message"]["content"] == expected
        assert calls[0][1]["questions"]["decision"]["type"] == task_type


def test_tool_call_rejected():
    body = {"model": "clm-latest", "messages": [{"role": "user", "content": "问题：选哪项？\nA. 好\nB. 差"}],
            "tools": [{"type": "function", "function": {"name": "x"}}]}
    r, _ = asyncio.run(request_case(body))
    assert r.status_code == 400
    assert "Tool calls" in r.text


def test_model_detail():
    r, _ = asyncio.run(request_case(endpoint="/v1/models/clm-latest", method="GET"))
    assert r.status_code == 200 and r.json()["id"] == "clm-latest"
    r, _ = asyncio.run(request_case(endpoint="/v1/models/not-exist", method="GET"))
    assert r.status_code == 404
