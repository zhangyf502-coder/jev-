#!/usr/bin/env bash
# Laya 0.4.6 single NVIDIA GPU=5, Docker 20.10.x; retains old containers and caches.
set -Eeuo pipefail

REPO_URL="https://github.com/NandhaKishorM/laya.git"
REPO_COMMIT="c73908d96ff73c0062c340a11bf7c54ec7d8bc4d"
DEPLOY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_ROOT="${WORK_ROOT:-/opt/laya-single5}"
REPO_DIR="${WORK_ROOT}/laya"
SECRET_FILE="${WORK_ROOT}/secrets/laya_api_key"
BASE_IMAGE="laya:0.4.6-cu128-base"
FINAL_IMAGE="laya:0.4.6-cu128-single5"
NAME="laya-single-gpu5"
VOLUME="laya_single_gpu5_cache_v1"
PORT="${LAYA_HOST_PORT:-8000}"
BIND_ADDR="${LAYA_BIND_ADDRESS:-127.0.0.1}"
GPU_INDEX=5

have_container() { docker container inspect "$1" >/dev/null 2>&1; }
fail() { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Missing command: $1"; }

precheck() {
  need docker; need git; need nvidia-smi
  [ "$(uname -m)" = "x86_64" ] || fail "This profile requires x86_64"
  docker version --format '{{.Server.Version}}' || fail 'Docker daemon unavailable'
  nvidia-smi -i "$GPU_INDEX" \
    --query-gpu=index,name,uuid,memory.total,memory.free,driver_version \
    --format=csv
  echo 'Docker runtimes:'
  docker info --format '{{json .Runtimes}}'
  echo 'Existing containers/ports:'
  docker ps -a --filter name=laya --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
  echo "Single GPU target: host GPU=${GPU_INDEX}; container sees cuda:0"
}

stop_old() {
  local n
  for n in laya-gpu5 laya-gpu6 laya-lb laya-gpu5-v2 laya-gpu6-v2 laya-lb-v2; do
    if have_container "$n"; then
      echo "Disabling restart and stopping old container: $n"
      docker update --restart=no "$n" >/dev/null
      docker stop "$n" >/dev/null
    fi
  done
  echo 'Old containers have not been deleted. Existing volumes/images remain intact.'
}

source_code() {
  need git
  mkdir -p "$WORK_ROOT"
  if [ ! -d "${REPO_DIR}/.git" ]; then
    if [ -e "$REPO_DIR" ]; then
      fail "${REPO_DIR} already exists but is not a Git checkout; refusing overwrite"
    fi
    git clone "$REPO_URL" "$REPO_DIR"
  fi
  cd "$REPO_DIR"
  if [ "$(git rev-parse HEAD)" != "$REPO_COMMIT" ]; then
    git fetch origin "$REPO_COMMIT"
    if [ -n "$(git status --porcelain)" ]; then
      fail 'Checkout has local modifications; refusing checkout overwrite'
    fi
    git checkout --detach "$REPO_COMMIT"
  fi
  echo "Source checked out: $(git rev-parse HEAD)"
}

build_images() {
  source_code
  cd "$REPO_DIR"
  docker build \
    --build-arg TORCH_INDEX=cu128 \
    --build-arg TORCH_VERSION=2.11.0 \
    -t "$BASE_IMAGE" .
  docker build -f "${DEPLOY_DIR}/Dockerfile.permissionfix" \
    -t "$FINAL_IMAGE" "$DEPLOY_DIR"
  docker image inspect "$FINAL_IMAGE" --format '{{.Id}}'
}

ensure_secret() {
  need openssl
  mkdir -p "${WORK_ROOT}/secrets"
  if [ ! -f "$SECRET_FILE" ]; then
    (umask 077; openssl rand -hex 32 > "$SECRET_FILE")
  fi
  chown 0:10001 "$SECRET_FILE"
  chmod 0440 "$SECRET_FILE"
}

start_service() {
  need docker
  docker image inspect "$FINAL_IMAGE" >/dev/null 2>&1 || fail "Image missing: ${FINAL_IMAGE}; run build first"
  ensure_secret
  if have_container "$NAME"; then
    local existing_image
    existing_image="$(docker inspect -f '{{.Config.Image}}' "$NAME")"
    [ "$existing_image" = "$FINAL_IMAGE" ] || fail "Container ${NAME} exists with image ${existing_image}; do not silently reuse it"
    docker start "$NAME"
    echo "Started existing container ${NAME}"
    return
  fi
  if command -v ss >/dev/null 2>&1; then
    echo "Current listeners on :${PORT}:"
    ss -lntp | grep -E ":${PORT}[[:space:]]" || true
  fi
  docker volume inspect "$VOLUME" >/dev/null 2>&1 || docker volume create "$VOLUME" >/dev/null
  echo "Creating ${NAME}, GPU=${GPU_INDEX}, ${BIND_ADDR}:${PORT} -> 8000"
  docker run -d \
    --name "$NAME" \
    --gpus '"device=5"' \
    --restart unless-stopped \
    --init \
    -p "${BIND_ADDR}:${PORT}:8000" \
    -v "${VOLUME}:/home/laya/.cache/huggingface" \
    -v "${SECRET_FILE}:/run/secrets/laya_api_key:ro,z" \
    -e LAYA_API_KEY_FILE=/run/secrets/laya_api_key \
    -e LAYA_DEVICE=cuda \
    -e LAYA_HOST=0.0.0.0 \
    -e LAYA_PORT=8000 \
    -e LAYA_PRELOAD=1 \
    -e LAYA_MODELS=english,multilingual \
    -e LAYA_MAX_LOADED=2 \
    -e LAYA_AUTO_TASK=0 \
    -e LAYA_MAX_CONCURRENT=8 \
    -e TORCH_DISABLE_NATIVE_JIT=1 \
    -e OMP_NUM_THREADS=4 \
    "$FINAL_IMAGE" laya-serve
  echo 'First start may download weights. Review the logs before smoke tests.'
}

status() {
  docker ps -a --filter "name=${NAME}" --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
  if have_container "$NAME"; then
    echo 'GPU reservation:'
    docker inspect -f '{{json .HostConfig.DeviceRequests}}' "$NAME"
    echo 'Cache mount:'
    docker inspect -f '{{range .Mounts}}{{if eq .Type "volume"}}{{println .Name .Destination}}{{end}}{{end}}' "$NAME"
  fi
}

check_gpu() {
  docker exec "$NAME" python -c 'import torch; print("torch:",torch.__version__, "runtime:",torch.version.cuda); assert torch.cuda.is_available(), "CUDA unavailable"; assert torch.cuda.device_count()==1, "expected exactly one visible GPU"; print("GPU:",torch.cuda.get_device_name(0),"capability:",torch.cuda.get_device_capability(0)); print(torch.ones(1,device="cuda").cpu())'
}

health() {
  need curl
  local key
  key="$(cat "$SECRET_FILE")"
  curl -fsS --max-time 15 -H "Authorization: Bearer ${key}" \
    "http://127.0.0.1:${PORT}/health"
  echo
}

smoke() {
  need curl
  local key
  key="$(cat "$SECRET_FILE")"
  echo 'HEALTH (verify checkpoint_devices resolves to cuda):'
  health
  echo 'PREDICTION:'
  curl -fsS --max-time 180 \
    -X POST "http://127.0.0.1:${PORT}/v1/systemone" \
    -H "Authorization: Bearer ${key}" \
    -H 'Content-Type: application/json' \
    --data-binary "@${DEPLOY_DIR}/request.json"
  echo
}

case "${1:-help}" in
  precheck) precheck ;;
  stop-old) stop_old ;;
  clone) source_code ;;
  build) build_images ;;
  start) start_service ;;
  status) status ;;
  gpu) check_gpu ;;
  health) health ;;
  smoke) smoke ;;
  logs) docker logs --tail 120 -f "$NAME" ;;
  stop) docker update --restart=no "$NAME"; docker stop "$NAME" ;;
  restart) docker restart "$NAME" ;;
  *)
    cat <<USAGE
Usage: bash deploy.sh <command>
  precheck  - host/Docker/GPU audit
  stop-old  - disable automatic restarts; stop prior dual-GPU Laya services
  clone     - clone/freeze Laya 0.4.6 source
  build     - build cu128 base + entrypoint permission-fixed runtime
  start     - create/start one single-GPU-5 HTTP service on port ${PORT}
  status    - show status, GPU reservation and cache mounts
  gpu       - verify torch sees exactly 1 GPU
  health    - authenticated health endpoint
  smoke     - health + decision inference
  logs      - stream service logs
  stop      - stop new Laya service (retain everything)
  restart   - restart new Laya service
USAGE
    ;;
esac
