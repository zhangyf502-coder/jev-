# Laya 0.4.6 — Docker 20.10.12 / CUDA 12.8 / 单物理 GPU 5

仓库：https://github.com/NandhaKishorM/laya
固定提交：`c73908d96ff73c0062c340a11bf7c54ec7d8bc4d`（0.4.6）

## 特点

- 单个容器 `laya-single-gpu5`，仅映射物理 GPU 5。容器里显示 `cuda:0` 正常。
- 不运行 Nginx 负载均衡，不占用 GPU 6。
- 新模型缓存卷 `laya_single_gpu5_cache_v1`，旧缓存不删除。
- 镜像由官方 Dockerfile 构建 `torch==2.11.0` + `cu128`，随后用轻量修复层调整 `/opt/laya` 的读取权限。
- API 监听宿主机回环地址 `127.0.0.1:8000`，开启 Bearer Token。
- 无容器自动删除选项，不执行删除容器/卷的操作。

## 快速部署

上传并解压发行包，例如：

```bash
mkdir -p /opt/laya-single5-launch
unzip laya_single_gpu5_deploy.zip -d /opt/laya-single5-launch
cd /opt/laya-single5-launch
chmod +x deploy.sh
bash deploy.sh precheck
bash deploy.sh stop-old
bash deploy.sh clone
bash deploy.sh build
bash deploy.sh start
bash deploy.sh status
bash deploy.sh logs
```

待模型下载及加载完成后，在新终端运行：

```bash
cd /opt/laya-single5-launch
bash deploy.sh gpu
bash deploy.sh health
bash deploy.sh smoke
```

模型 API：`POST http://127.0.0.1:8000/v1/systemone`
批量 API：`POST http://127.0.0.1:8000/v1/systemone/batch`
健康 API：`GET http://127.0.0.1:8000/health`

## 环境核验

```bash
uname -m
docker version
nvidia-smi -L
nvidia-smi -i 5 --query-gpu=index,name,uuid,memory.free,driver_version --format=csv
docker info --format '{{json .Runtimes}}'
ss -lntp | grep ':8000 ' || true
```

当 `docker --gpus` 报找不到 NVIDIA runtime 时，需要由管理员检查 NVIDIA Container Toolkit，而非重启或改动现有其他容器。

## 注意：上次启动失败

原错误：`python: can't open file '/opt/laya/entrypoint.py': [Errno 13] Permission denied`。
本方案 `Dockerfile.permissionfix` 从基础镜像复制权限修复层，再切回 UID 10001，构建时执行运行用户权限测试。旧容器不修改、不删除。

## 镜像构建失败时

检查 Docker daemon 可达性、镜像仓库连通性、内存和磁盘空间。`2.11.0` 在官方 PyTorch cu128 index 中可用。如果 `check_torch.py` 对 CuSPARSELt 检查失败，保存完整错误日志并检查实际 PyTorch 安装包依赖，勿盲目跳过检查。

## ModelScope 下载替代（可选）

默认首次服务启动从 Hugging Face 下载两个 checkpoint。如果机房只通 ModelScope，可以先构建包含预下载权重的基础镜像，再构建权限修复层（保持版本和 tag）：

```bash
cd /opt/laya-single5/laya
docker build \
  --build-arg TORCH_INDEX=cu128 \
  --build-arg TORCH_VERSION=2.11.0 \
  --build-arg MODELSCOPE_MODEL='english multilingual' \
  -t laya:0.4.6-cu128-base .
cd /opt/laya-single5-launch
docker build -f Dockerfile.permissionfix -t laya:0.4.6-cu128-single5 .
```

注意：若之前创建了空缓存卷，一般 Docker 会将镜像中预置缓存复制到首次新建的命名卷；若该卷已有内容，可能掩盖新镜像中预置的模型。此时应使用新的卷名，不应删除旧卷。若需要彻底离线，请在创建容器时额外设置 `HF_HUB_OFFLINE=1`，并确保缓存和镜像中包含所需权重。

## 日常运维

```bash
bash deploy.sh status
bash deploy.sh logs
bash deploy.sh stop
bash deploy.sh restart
```

## 外部测试访问

默认不向公网暴露端口。在个人电脑用 SSH 隧道：

```bash
ssh -L 18000:127.0.0.1:8000 root@YOUR_SERVER_IP
```

客户端在本机向 `http://127.0.0.1:18000/v1/systemone` 发送带 Bearer Token 的 JSON 即可。不要将明文 HTTP 加 Token 直接发布到公网；应使用 HTTPS/TLS 反向代理。

## 验收标准

1. `docker inspect` 的 GPU DeviceIDs 只包含 `5`；
2. 容器 torch 报告 CUDA 可用，且只有一张可见 GPU；
3. `GET /health` 有已加载 checkpoint 对应的 CUDA 设备，而不只是配置值；
4. `POST /v1/systemone` 获得包含 answers 的正常响应；
5. 模型缓存卷在容器停止、重新启动后仍然存在。
